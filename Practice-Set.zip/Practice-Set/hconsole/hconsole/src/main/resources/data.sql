insert into user values(100,sysdate(),'Veena');
insert into user values(101,sysdate(),'Shiva');
insert into user values(102,sysdate(),'Again');
insert into post values(200,'Veena',100);
insert into post values(201,'Shiva',100);
insert into post values(202,'Again',102);

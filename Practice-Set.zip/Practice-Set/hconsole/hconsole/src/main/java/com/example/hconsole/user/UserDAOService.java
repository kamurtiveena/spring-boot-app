package com.example.hconsole.user;

import java.util.*;

import org.springframework.stereotype.Component;

@Component
public class UserDAOService {
	private static int usersCount=2;
	private static List<User> users=new ArrayList<>();
	static {
		users.add(new User(1,"Veena",new Date()));
		users.add(new User(2,"Shiva",new Date()));
	}
	public List<User> findAll()
	{
		return users;
	}
	public User save(User user) {
			if(user.getId()==null)
			user.setId(++usersCount);
		
		users.add(user);
		return user;
	}
	
	public User findOne(int id) {
		for(User user:users) {
			if(user.getId() == id)
				return user;
		}
		return(null);
	}
	
	public String deleteOne(int id) {
		for(User user:users) {
			if(user.getId() == id)
				users.remove(user);
				return "user deleted";
		}
		return("no user exist");
	}
}

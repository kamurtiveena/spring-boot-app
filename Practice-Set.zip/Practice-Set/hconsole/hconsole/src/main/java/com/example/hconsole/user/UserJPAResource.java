package com.example.hconsole.user;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class UserJPAResource {

	@Autowired
	private UserDAOService service;

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PostRepository postRepository;

	@GetMapping("/jpa/users")
	public List<User> retrieveAll() {
		return userRepository.findAll();
	}

	@GetMapping("/jpa/user/{id}/posts")
	public List<Post> retrieveAllPost(@PathVariable int id) {
		Optional<User> user = userRepository.findById(id);
		if (!user.isPresent())
			System.out.print("No User");
		return user.get().getPost();
	}

	@GetMapping("/jpa/user/{id}")
	public Optional<User> retrieveUser(@PathVariable int id) {
		Optional<User> user = userRepository.findById(id);
		// Applied HATEOAS
//		Resource<User> resource=new Resource<User>(user);
//		ControllerLinkBuilder.linkTo()		
		return user;
	}

	@DeleteMapping("/jpa/user/{id}")
	public void deleteUser(@PathVariable int id) {
		userRepository.deleteById(id);
	}

	@DeleteMapping("/jpa/user/{id}/post/{pid}")
	public void deleteUserPost(@PathVariable int id,@PathVariable int pid) {
		Optional<User> user = userRepository.findById(id);
		if (!user.isPresent())
			System.out.print("No User");
		else
			postRepository.deleteById(pid);
	}

	@PostMapping("/jpa/user")
	public ResponseEntity<Object> createUser(@RequestBody User user) {

		User saveduser = userRepository.save(user);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(saveduser.getId())
				.toUri();

		return ResponseEntity.created(location).build();
	}

	@PostMapping("/jpa/user/{id}/posts")
	public ResponseEntity<Object> createUserPost(@PathVariable int id, @RequestBody Post post) {

		Optional<User> user = userRepository.findById(id);
		if (!user.isPresent())
			System.out.print("No User");

		User userF = user.get();

		post.setUser(userF);
		Post savedPost = postRepository.save(post);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedPost.getId())
				.toUri();

		return ResponseEntity.created(location).build();
	}
}

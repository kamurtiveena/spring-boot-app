package com.example.demo.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.example.demo.user.UserNotFoundException;

@ControllerAdvice
@RestController
public class CustomizeREEH extends ResponseEntityExceptionHandler {
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleExceptionEntity(Exception ex, WebRequest request) throws Exception {
	
			ExceptionResponse r = new ExceptionResponse(new Date(),ex.getMessage(),"Hey you Noob"+ request.getDescription(false));
			return new ResponseEntity(r,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public final ResponseEntity<Object> handleUserExceptionEntity(UserNotFoundException ex, WebRequest request) throws Exception {
			ExceptionResponse r = new ExceptionResponse(new Date(),ex.getMessage(),"Hey you Noob"+ request.getDescription(false));
			return new ResponseEntity(r,HttpStatus.ACCEPTED);
		
	}
}

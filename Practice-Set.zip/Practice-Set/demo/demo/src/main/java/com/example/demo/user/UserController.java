package com.example.demo.user;

import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
//import org.springframework.hateoas.mvc.ControllerLinkBuilder.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;

import filter.SomeBean;
import io.swagger.annotations.ApiOperation;
import versioning.Name;
import versioning.Person;
import versioning.Person2;

@RestController
public class UserController {

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private UserDAOService service;

	// retrieve all users
	@ApiOperation(value = "View a list of available users")
	@GetMapping("/users")
	public List<User> retrieveAll() {
		return service.findAll();
	}

	@GetMapping("/hello-internationalization")
	public String hellloAll() {
		return messageSource.getMessage("good.morning.message", null, LocaleContextHolder.getLocale());
	}

	@GetMapping("/user/{id}")
	public User retrieveUser(@PathVariable int id) {
		User user = service.findOne(id);
		if (user == null)
			throw new UserNotFoundException("id-" + id);
		// Applied HATEOAS
//		Resource<User> resource=new Resource<User>(user);
//		ControllerLinkBuilder.linkTo()		
		return user;
	}

	@DeleteMapping("/user/{id}")
	public String deleteUser(@PathVariable int id) {

		return service.deleteOne(id);
	}

	@PostMapping("/user")
	public ResponseEntity<Object> createUser(@Valid @RequestBody User user) {

		User saveduser = service.save(user);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(saveduser.getId())
				.toUri();

		return ResponseEntity.created(location).build();
	}

	@GetMapping("/getfiltered")
	public MappingJacksonValue somebean() {
		SomeBean someone=new SomeBean("Veenu","Shiva","Meghana");
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("val1","val2");
		FilterProvider filters= new SimpleFilterProvider().addFilter("SomeBeanFilter",filter );
				
		MappingJacksonValue mapping=new MappingJacksonValue(someone);
		mapping.setFilters(filters);
		return mapping; 
	}

	@GetMapping("/getfilm")
	public MappingJacksonValue somebeanm() {
		
		List<SomeBean> someone=Arrays.asList(new SomeBean("Veenu", "Shiva", "Meghana"), 
											 new SomeBean("Veenu", "Shiva", "Meghana"));
		SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("val1");
		FilterProvider filters= new SimpleFilterProvider().addFilter("SomeBeanFilter",filter );
				
		MappingJacksonValue mapping=new MappingJacksonValue(someone);
		mapping.setFilters(filters);
		return mapping; 
		
//		return Arrays.asList(new SomeBean("Veenu", "Shiva", "Meghana"), new SomeBean("Veenu", "Shiva", "Meghana"));
	}
	
	
	@GetMapping("/v1")
	public Person pipv1() {
		return new Person("Only Veena");
	}

	@GetMapping("/v2")
	public Person2 pipv2() {
		return new Person2(new Name("Only","Veena"));
	}
	
	
//	@GetMapping("/users/{id}/posts/{post_id}")
//	public List<User> retrieveAll(){
//		return service.findAll();
//	}
//	
//	@GetMapping("/users/{id}/posts")
//	public User retrieveUser(@PathVariable int id){
//		User user = service.findOne(id);
//		if(user==null)
//			throw new UserNotFoundException("id-"+id);
//		return user;
//		
//	}
//	
//	@PostMapping("/users/{id}/posts")
//	public ResponseEntity<Object> createUser(@RequestBody User user ){
//		User saveduser=service.save(user);
//		URI location= ServletUriComponentsBuilder
//		.fromCurrentRequest()
//		.path("/{id}")
//		.buildAndExpand(saveduser.getId()).toUri();
//		
//		return ResponseEntity.created(location).build();
//	}

}

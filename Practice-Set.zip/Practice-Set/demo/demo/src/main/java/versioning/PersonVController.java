package versioning;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PersonVController {
	
	@GetMapping("/v1")
	public Person pipv1() {
		return new Person("Only Veena");
	}

	@GetMapping("/v2")
	public Person2 pipv2() {
		return new Person2(new Name("Only","Veena"));
	}
}

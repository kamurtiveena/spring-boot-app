package filter;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FilteringEx {
	
	@GetMapping("/getfiltered")
	public SomeBean somebean() {
		return new SomeBean("Veenu","Shiva","Meghana");
	}
}

insert into user values(100,sysdate(),'AhB');
insert into user values(101,sysdate(),'ABC');
insert into user values(102,sysdate(),'ABCD');